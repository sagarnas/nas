$("input:checkbox[name='open-content']").click(function(){
    $(".hide-hundred").css("display","none")
}) 